import { create } from 'zustand';
import { persist, createJSONStorage } from 'zustand/middleware';
import AsyncStorage from '@react-native-async-storage/async-storage';

import { useLanePlayStore } from '@/features/lane-play';

import { calculateScores } from '../utils/scoreCalculator';
import { isFrameComplete, pinsStandingForNextRoll, FRAME_COUNT, PINS_PER_RACK } from '../utils/frameRules';
import type { CompletedGame } from '../types';

const FULL_RACK = (): boolean[] => Array(PINS_PER_RACK).fill(true);
const EMPTY_GAME = (): number[][] => Array.from({ length: FRAME_COUNT }, () => []);

interface ScoringState {
  /** Raw pinfall per ball, grouped by frame. The single source of truth — frame/cumulative scores are always derived from this via `calculateScores`, never stored. */
  frames: number[][];
  currentFrameIndex: number;
  isGameComplete: boolean;
  gameHistory: CompletedGame[];

  /**
   * Snapshot of the shared `lane-play` PinRack taken right before the ball
   * about to be thrown. `submitBall` diffs the rack's *current* state
   * against this snapshot to derive how many pins fell on that one ball —
   * the rack itself only ever represents "what's standing right now", so
   * pinfall has to be inferred rather than read directly.
   */
  pinsStandingBeforeBall: boolean[];

  /** Reads the shared PinRack, records this ball's pinfall against the current frame, advances frame/game state, and re-racks the shared pins when a frame (or a 10th-frame fill ball) calls for it. */
  submitBall: () => void;
  /** Starts a brand-new game: clears frames/history-in-progress and resets the shared lane-play session (oil volume, shot log, pin rack) so the new game starts on a fresh lane. */
  startNewGame: () => void;
}

export const useScoringStore = create<ScoringState>()(
  persist(
    (set, get) => ({
      frames: EMPTY_GAME(),
      currentFrameIndex: 0,
      isGameComplete: false,
      gameHistory: [],
      pinsStandingBeforeBall: FULL_RACK(),

      submitBall: () => {
        const { frames, currentFrameIndex, isGameComplete, pinsStandingBeforeBall } = get();
        if (isGameComplete) return;

        const lanePlay = useLanePlayStore.getState();

        const standingBefore = pinsStandingBeforeBall.filter(Boolean).length;
        const standingAfter = lanePlay.pins.filter(Boolean).length;
        const pinfall = Math.max(0, standingBefore - standingAfter);

        const updatedFrames = frames.map((rolls, i) =>
          i === currentFrameIndex ? [...rolls, pinfall] : rolls
        );
        const updatedRolls = updatedFrames[currentFrameIndex];

        // Log the shot against the shared oil-depletion/coach model, but
        // don't let it auto-reset the rack — this store owns reset timing
        // across a frame's 2-3 balls.
        lanePlay.logShot(false);

        // Two patches to the entry `logShot` just created, both only
        // relevant for ball 2+ of a frame (a fresh first ball is always
        // correctly labeled already):
        //
        // 1. `logShot` always labels an all-clear rack as "Strike", which is
        //    only actually true when the ball was thrown at a freshly-racked
        //    10 pins. Clearing out whatever was left standing from a prior
        //    ball is a spare conversion, not a strike.
        // 2. If the *previous* ball in this same frame carried a
        //    `frictionAlert` (it left the weak-side corner pin standing —
        //    10 for a right-handed bowler, 7 for a left-handed bowler),
        //    that signal needs to survive onto this ball too — most bowlers
        //    log a whole frame's balls only after they've thrown both, so
        //    by the time this entry exists the coach needs to already see
        //    the friction read rather than losing it the moment "Spare"
        //    overwrites the leave text.
        const isContinuationBall = frames[currentFrameIndex].length > 0;
        const isSpareClose = standingAfter === 0 && standingBefore !== PINS_PER_RACK;
        const previousBallInFrame = isContinuationBall ? useLanePlayStore.getState().shotLog[1] : undefined;
        const carryFrictionForward = Boolean(previousBallInFrame?.frictionAlert);

        if (isSpareClose || carryFrictionForward) {
          useLanePlayStore.setState((state) => ({
            shotLog: state.shotLog.map((shot, i) =>
              i === 0
                ? {
                    ...shot,
                    ...(isSpareClose ? { leave: 'Spare' } : {}),
                    frictionAlert: shot.frictionAlert || carryFrictionForward,
                  }
                : shot
            ),
          }));
        }

        const frameDone = isFrameComplete(currentFrameIndex, updatedRolls);
        const isLastFrame = currentFrameIndex === FRAME_COUNT - 1;
        const gameDone = isLastFrame && frameDone;

        const needsFreshRack = frameDone
          ? !gameDone
          : pinsStandingForNextRoll(currentFrameIndex, updatedRolls) === PINS_PER_RACK;

        if (needsFreshRack) {
          useLanePlayStore.setState({ pins: FULL_RACK() });
        }

        set({
          frames: updatedFrames,
          currentFrameIndex: frameDone && !isLastFrame ? currentFrameIndex + 1 : currentFrameIndex,
          isGameComplete: gameDone,
          pinsStandingBeforeBall: needsFreshRack ? FULL_RACK() : useLanePlayStore.getState().pins,
        });

        if (gameDone) {
          const results = calculateScores(updatedFrames);
          const finalScore = results[FRAME_COUNT - 1].cumulativeScore ?? 0;
          set((state) => ({
            gameHistory: [
              {
                id: `${Date.now()}`,
                playedAt: new Date().toISOString(),
                frames: updatedFrames,
                finalScore,
              },
              ...state.gameHistory,
            ],
          }));
        }
      },

      startNewGame: () => {
        useLanePlayStore.getState().resetSession();
        set({
          frames: EMPTY_GAME(),
          currentFrameIndex: 0,
          isGameComplete: false,
          pinsStandingBeforeBall: FULL_RACK(),
        });
      },
    }),
    {
      name: 'scoring-store',
      storage: createJSONStorage(() => AsyncStorage),
      // Only the game history needs to survive an app restart indefinitely;
      // an in-progress game resuming mid-frame after a restart is fine too,
      // so we persist everything except the transient rack snapshot, which
      // gets re-derived as PINS_PER_RACK-standing on the next submitBall
      // call in the worst case.
      partialize: (state) => ({
        frames: state.frames,
        currentFrameIndex: state.currentFrameIndex,
        isGameComplete: state.isGameComplete,
        gameHistory: state.gameHistory,
      }),
    }
  )
);
