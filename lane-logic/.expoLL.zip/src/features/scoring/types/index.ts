/**
 * A single frame's score, derived from its raw rolls. `frameScore` and
 * `cumulativeScore` are `null` until enough *future* rolls exist to resolve
 * a strike/spare bonus (e.g. frame 3's score can't be known until the bowler
 * has thrown the next one or two balls) — the UI should render a blank/dash
 * for `null` rather than a 0.
 */
export interface FrameResult {
  rolls: number[];
  frameScore: number | null;
  cumulativeScore: number | null;
  isStrike: boolean;
  isSpare: boolean;
}

/** A finished game, kept in `gameHistory` for the Analytics feature to read later. */
export interface CompletedGame {
  id: string;
  playedAt: string;
  frames: number[][];
  finalScore: number;
}
