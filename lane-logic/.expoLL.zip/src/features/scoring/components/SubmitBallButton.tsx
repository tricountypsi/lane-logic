import { View, Text, Pressable } from 'react-native';

import { useScoringStore } from '../store/useScoringStore';

/**
 * Primary scoring action. Reads whatever's currently toggled on the shared
 * `lane-play` PinRack and commits it as the next ball; once the 10th frame
 * closes out, this swaps to a "New Game" action that resets both the
 * scoring state and the shared lane-play session.
 */
export function SubmitBallButton() {
  const submitBall = useScoringStore((state) => state.submitBall);
  const startNewGame = useScoringStore((state) => state.startNewGame);
  const isGameComplete = useScoringStore((state) => state.isGameComplete);

  if (isGameComplete) {
    return (
      <View className="gap-2">
        <Text className="text-center text-sm text-white/60">Game complete!</Text>
        <Pressable onPress={startNewGame} className="items-center rounded-lg bg-cyan-400 py-3">
          <Text className="font-bold text-black">New Game</Text>
        </Pressable>
      </View>
    );
  }

  return (
    <Pressable onPress={submitBall} className="items-center rounded-lg bg-cyan-400 py-3">
      <Text className="font-bold text-black">Submit Ball</Text>
    </Pressable>
  );
}
