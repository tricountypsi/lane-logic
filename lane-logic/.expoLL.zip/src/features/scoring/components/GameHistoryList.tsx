import { View, Text } from 'react-native';

import { useScoringStore } from '../store/useScoringStore';

/** Scrollable-by-parent list of completed games, newest first. Feeds the future Analytics feature the same `gameHistory` data this list reads from. */
export function GameHistoryList() {
  const gameHistory = useScoringStore((state) => state.gameHistory);

  if (gameHistory.length === 0) {
    return <Text className="text-sm text-white/40">No completed games yet — finish a frame 10 to log one.</Text>;
  }

  return (
    <View className="gap-2">
      {gameHistory.slice(0, 10).map((game) => (
        <View key={game.id} className="flex-row items-center justify-between rounded bg-white/5 px-3 py-2">
          <Text className="text-xs text-white/70">{new Date(game.playedAt).toLocaleString()}</Text>
          <Text className="text-sm font-bold text-cyan-300">{game.finalScore}</Text>
        </View>
      ))}
    </View>
  );
}
