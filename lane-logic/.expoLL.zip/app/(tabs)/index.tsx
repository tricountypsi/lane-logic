import { useRouter } from 'expo-router';
import { View, Text } from 'react-native';
import LinearGradient from 'react-native-linear-gradient';
import Svg, { Defs, RadialGradient, Stop, Rect } from 'react-native-svg';

import { GlowButton } from '@/components/ui';
import { BowlingBallIcon, GearIcon } from '@/components/ui/icons';

/**
 * Home / title screen — first thing the bowler sees on launch. Styled to
 * match the approved title-screen reference: a dark brushed-metal-style
 * backdrop, a glowing cyan wordmark, and two neon-outlined pill buttons.
 *
 * One deliberate simplification from the reference: the reference art used
 * a photoreal 3D globe in place of the "O" in "LOGIC". Reproducing that
 * exactly would need an actual image asset, so this pass instead repeats
 * the bowling-ball glyph (already used for the Bowl button) as the accent —
 * consistent with a bowling app's actual subject matter, and swappable for
 * real artwork later without touching layout.
 *
 * Settings routes to the `profile` tab (the closest existing destination
 * until a dedicated settings screen exists); Bowl routes to `scoring`,
 * which is where a game actually starts.
 */
export default function HomeScreen() {
  const router = useRouter();

  return (
    <LinearGradient colors={['#2a2a30', '#15151a', '#0a0a0d']} style={{ flex: 1 }}>
      <View className="flex-1 items-center justify-center px-6">
        {/* Soft radial glow seated behind the wordmark, built from SVG
            primitives rather than an image asset. */}
        <Svg
          style={{ position: 'absolute', top: '18%', width: '100%', height: 320 }}
          viewBox="0 0 400 320"
        >
          <Defs>
            <RadialGradient id="logoGlow" cx="50%" cy="45%" r="60%">
              <Stop offset="0%" stopColor="#22d3ee" stopOpacity={0.35} />
              <Stop offset="100%" stopColor="#22d3ee" stopOpacity={0} />
            </RadialGradient>
          </Defs>
          <Rect x="0" y="0" width="400" height="320" fill="url(#logoGlow)" />
        </Svg>

        <View className="items-center">
          {/* Single nested-Text run (rather than sibling Views) so the
              mixed-color "A" sits on the same baseline as the rest of the
              word — RN aligns nested Text spans automatically, where
              separate flex children at this font size can drift. */}
          <Text
            className="text-6xl font-extrabold tracking-wide text-white"
            style={{ textShadowColor: '#22d3ee', textShadowRadius: 16, textShadowOffset: { width: 0, height: 0 } }}
          >
            L<Text className="text-cyan-300">A</Text>NE
          </Text>

          <View className="-mt-2 flex-row items-center">
            <Text
              className="text-6xl font-extrabold tracking-wide text-white"
              style={{ textShadowColor: '#22d3ee', textShadowRadius: 16, textShadowOffset: { width: 0, height: 0 } }}
            >
              L
            </Text>
            <View className="mx-1 items-center justify-center">
              <BowlingBallIcon size={44} color="#1d6fe0" holeColor="#d9eaff" />
            </View>
            <Text
              className="text-6xl font-extrabold tracking-wide text-white"
              style={{ textShadowColor: '#22d3ee', textShadowRadius: 16, textShadowOffset: { width: 0, height: 0 } }}
            >
              GIC
            </Text>
          </View>
        </View>

        <View className="mt-16 w-full max-w-sm flex-row gap-4">
          <View className="flex-1">
            <GlowButton label="Settings" icon={<GearIcon size={18} />} onPress={() => router.push('/profile')} />
          </View>
          <View className="flex-1">
            <GlowButton
              label="Bowl"
              icon={<BowlingBallIcon size={18} />}
              variant="filled"
              onPress={() => router.push('/scoring')}
            />
          </View>
        </View>
      </View>

      <Text className="absolute bottom-6 right-6 text-lg text-white/20">✦</Text>
    </LinearGradient>
  );
}
